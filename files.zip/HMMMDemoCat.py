from HMMMImplementation import *

myList = [Command(CommandTypes.READ, 1),
          Command(CommandTypes.WRITE, 1)]

runProgram(myList)
